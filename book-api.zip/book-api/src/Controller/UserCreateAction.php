<?php

declare(strict_types=1);

namespace App\Controller;

use App\Component\User\UserManager;
use App\Component\User\UserFactory;
use App\Repository\UserRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Validator\Validator\ValidatorInterface;

class UserCreateAction extends AbstractController
{
    public function __construct(
        private readonly UserFactory $userFactory,
        private readonly UserManager $userManager,
        private readonly ValidatorInterface $validator,
        private readonly UserRepository $userRepository
    ) {}

    public function __invoke(Request $request): JsonResponse
    {
        // JSON ma'lumotlarni olish va dekodlash
        $data = json_decode($request->getContent(), true);

        if ($data === null) {
            return new JsonResponse(['error' => 'Invalid JSON format'], Response::HTTP_BAD_REQUEST);
        }

        // Majburiy maydonlarni tekshirish
        $requiredFields = ['email', 'password', 'age', 'gender', 'phone'];
        foreach ($requiredFields as $field) {
            if (!isset($data[$field])) {
                return new JsonResponse(['error' => "$field maydoni talab qilinadi"], Response::HTTP_BAD_REQUEST);
            }
        }

        // Email bo‘yicha foydalanuvchi mavjudligini tekshirish
        if ($this->userRepository->findOneBy(['email' => $data['email']]) !== null) {
            return new JsonResponse(['error' => 'Bu email allaqachon ro‘yxatdan o‘tgan.'], Response::HTTP_BAD_REQUEST);
        }

        // Yangi foydalanuvchi yaratish
        $newUser = $this->userFactory->create(
            $data['email'],
            $data['password'],
            (int) $data['age'],
            $data['gender'],
            $data['phone']
        );

        // Validatsiyani tekshirish
        $errors = $this->validator->validate($newUser);
        if (count($errors) > 0) {
            $errorMessages = [];
            foreach ($errors as $error) {
                $errorMessages[] = $error->getPropertyPath() . ': ' . $error->getMessage();
            }
            return new JsonResponse(['errors' => $errorMessages], Response::HTTP_BAD_REQUEST);
        }

        // Yangi foydalanuvchini bazaga saqlash
        $this->userManager->save($newUser, true);

        return new JsonResponse(['message' => 'User created successfully'], Response::HTTP_CREATED);
    }
}
