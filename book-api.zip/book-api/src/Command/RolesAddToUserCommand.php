<?php

namespace App\Command;

use App\Component\User\UserManager;
use App\Repository\UserRepository;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Question\Question;
use Symfony\Component\Console\Style\SymfonyStyle;

#[AsCommand(
    name: 'roles:add-to-user',
    description: 'add roles to User ',
)]
class RolesAddToUserCommand extends Command
{
    public function __construct(private UserRepository $userRepository, private UserManager $userManager)
    {
        parent::__construct();
    }
    protected function execute ( InputInterface $input, OutputInterface $output): int
    {
        $io = new SymfonyStyle($input, $output);

        $askId = new Question( "Foydalanuvchi Id'sini kiriting!!!");
        $askRole = new Question("Foydalanuvchi Roli'ni kiriting!!! ");
        $questionHelper = $this->getHelper('question');

        $user = null;
        $role = null;

// $user qiymati null'ga teng bo'lsa aylana ishlaydi
        while (!$user) {
            //ushbu qatorda id'sini kiritishini so'rayapmiz va kiritilgan ma'lumotni id o'zgaruvchanida saqlayabmiz
            $id = $questionHelper->ask($input, $output, $askId);

            //bu yerda id null emasligini tekshiryabmiz
            if ($id === null) {
                $io->warning("Iltimos id'ni kiriting!!!");
            } else {
                //kiritilgan id'ga mos user'ni bazadan topyabmiz
                $user = $this->userRepository->find($id);

                //agar topilmasa xato chiqaryabmiz
                if ($user === null) {
                    $io->warning("Bunday foydalanuvchi mavjud emas!!!");
                }
            }
        }
        //toki to'gri formatdagi Role kiritmaguncha,role kiritihini so'raymiz
        while (!preg_match("/^ROLE_[A-Z]{4,20}$/", $role)) {
            //bu yerda role so'rayabmiz
            $role = $questionHelper->ask($input, $output, $askRole);

            //kiritilgan role noto'g'ri bo'lsa xato chiqaramiz
            if (!preg_match("/^ROLE_[A-Z]{4,20}$/",$role)) {
                $io->warning("Noto'g'ri role kiritdingizku axir!!!");
            }
        }

        //user'ni role massivini yangi massivga olib oldik
        $roles=$user->getRoles();

        //agar role massivda kiritilayotgan yangi role mavjud bo'lmasa if ishlasin
        if (!in_array($role,$roles,true)){
            //ushbu massivga qo'shimcha yangi kiritilgan role'ni qo'shdik
            $roles[] = $role;

            //yangi yaratilgan massivni user'ni role xususiyatiga set qildik
            $user->setRoles($roles);

            //user'ni saqladik
            $this->userManager->save($user,true);

            $io->success("Role muvaffaqiyatli biriktirildi.barakalla!!!");
        }



            return Command::SUCCESS;
    }
}
